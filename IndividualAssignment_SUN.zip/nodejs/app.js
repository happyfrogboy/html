const http = require('http');
const hostname = '127.0.0.1';
const port = 3000;
const fs = require('fs');
  // now date
var today = new Date()
  // a data in a new line
var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate() + '\n';

http.createServer((req, res) => {
  res.statusCode = 200;
	res.setHeader('Content-Type', 'text/plain');
   console.log('Welcome to the server.');
	// filename
  filename = './datelog.txt'
	if (req.method === 'POST' && req.url == '/logdate') { // /logdate
		// the server log
		console.log('post' + req.url)
		// if the file isn't existed, create a new datelog.txt
    fs.writeFile(filename, date, { 'flag': 'a+' },err => {
			//error
      if (err) {
				res.write("error");
				// throw error
        throw err;
      } else {
				// 
        console.log('write', date)
        res.write('write ' + date);
      }
      res.end();
    })
	} else if (req.method === 'GET' && req.url == '/dates') { // /dates
		// the server log		
		console.log('get' + req.url)
		// read datalog.txt, if the file isn't existed, create a new datelog.txt
    fs.readFile(filename, {encoding:'utf-8', 'flag': 'a+'},(err,data)=>{
			// error
      if(err){
        console.log("error");
        res.write("error");
      }else{
				// read file and return
        console.log('read datelog.txt successfully');
        console.log(data);
        res.write(data)
      }
      res.end();
    });
	} else { // other request
		// the server log		
		console.log(req.method + ' ' + req.url)
		// 404
    res.statusCode = 404
    res.write("404");
    res.end()
  }

}).listen(port, hostname);
console.log(`Server running at http://${hostname}:${port}/`);
